# Textänderungen vom 21.10.2026

Gilt für die Live-Seiten **Startseite, Produkt, SMELL Test und Über uns**. Alle
anderen Seiten (FAQ, Kontakt, Vertriebspartner, Impressum, Datenschutz), Kopf-
und Fusszeile bleiben unverändert.

So anwenden:
- Im **vorhandenen** HTML-Widget der Live-Seite die Stelle «Alt» suchen und genau
  diese Stelle durch «Neu» ersetzen. Alles andere bleibt, wie es ist – auch
  Änderungen, die früher in Cowork gemacht wurden.
- Einrückung und Zeilenumbrüche können auf der Live-Seite abweichen; massgebend
  ist der Text. Interne Links stehen dort bereits als echte Adressen (`/kontakt/…`
  statt `kontakt.html`) – das ist kein Unterschied.
- `…(eingebettetes Bild, unverändert)…` steht für ein langes `data:`-Bild; nur
  das `alt`-Attribut bzw. der Text daneben ändert sich.
- Ist eine «Alt»-Stelle auf der Live-Seite nicht (mehr) zu finden, weil sie in
  Cowork schon geändert wurde: **nicht raten**, die Stelle auslassen und melden.

## Startseite (`startseite`) – 7 Änderungen

**1. CSS ergänzen** – im ersten `<style>`-Block direkt nach der Zeile
`@media print { .sdx .sd-top { display: none; } }` einfügen:

```css

/* ================================================================
   21. Hinweis unter den drei Schritten
   ================================================================ */
.sdx .sd-wdh {
  display: table; margin: 30px auto 0; padding: 12px 26px; border-radius: 999px;
  background: var(--white); box-shadow: inset 0 0 0 1.5px var(--blue-soft);
  font-size: 16px; font-weight: 700; color: var(--navy); text-align: center;
}
```

**2. Ersetzen**

Alt:

```html
          Der SMELL Discettes Olfaction Test ist ein klinisch erprobter Riech-Screening-Test mit acht
          konzentrierten Riechstoffen. Entwickelt an der Universität Zürich, in
          Publikationen bestätigt und vollständig an MPA oder Pflege delegierbar.
```
Neu:

```html
          Der SMELL Discettes Olfaction Test ist ein klinisch erprobter, vollständig an
          Assistenz MPA oder Pflege delegierbarer Riech-Screening-Test mit acht Riechstoffen.
          Er wurde an der Universität Zürich entwickelt und in Publikationen bestätigt.
```

**3. Ersetzen**

Alt:

```html
          Der gesamte Ablauf ist an MPA oder Pflege delegierbar und liefert ein sofort
          dokumentierbares Ergebnis.
```
Neu:

```html
          Der gesamte Ablauf ist vollständig an medizinische Praxisassistenz und
          Pflegepersonal delegierbar und liefert sofort das sauber dokumentierte Ergebnis.
```

**4. Ersetzen**

Alt:

```html
          <p>Mit einem oder beiden Nasenlöchern an der geöffneten Diskette riechen.</p>
```
Neu:

```html
          <p>Mit dem gewählten Nasenloch an der geöffneten Diskette riechen.</p>
```

**5. Ersetzen**

Alt:

```html
          <p>Aus drei Bildantworten die passende wählen. Das Ergebnis liegt sofort vor.</p>
        </article>
      </div>
```
Neu:

```html
          <p>Aus drei Bildantworten die passende wählen.</p>
        </article>
      </div>
      <p class="sd-wdh">Mit allen 8 Discettes wiederholen</p>
```

**6. Ersetzen**

Alt:

```html
          <li><span><b>Dokumentierbar für die Krankengeschichte.</b> Klar nachvollziehbares Ergebnis auf dem Auswertungsbogen.</span></li>
```
Neu:

```html
          <li><span><b>Dokumentierbar für die Krankengeschichte.</b> Klar nachvollziehbares Ergebnis auf dem Formular.</span></li>
```

**7. Ersetzen**

Alt:

```html
            aktuellen Auswertungsbögen und Gebrauchsanweisungen. Sie möchten das <span class="sd-nw">SMELL Test-Set</span> nutzen oder in Ihrem Markt vertreiben? Sprechen Sie uns an.
```
Neu:

```html
            aktuellen Formulare und Gebrauchsanweisungen. Sie möchten das <span class="sd-nw">SMELL Test-Set</span> nutzen oder in Ihrem Markt vertreiben? Sprechen Sie uns an.
```


## Produkt (`produkt`) – 7 Änderungen

**1. Ersetzen** (nur der sichtbare Text bzw. das Attribut – das Bild bleibt)

Alt:

```html
        <img src="…(eingebettetes Bild, unverändert)…" alt="Geöffnete TestBox mit acht einzeln verpackten SMELL Discettes und Auswertungsbogen" width="1700" height="956">
```
Neu:

```html
        <img src="…(eingebettetes Bild, unverändert)…" alt="Geöffnete TestBox mit acht einzeln verpackten SMELL Discettes und Formular" width="1700" height="956">
```

**2. Ersetzen**

Alt:

```html
          ob ein normaler Riechsinn vorliegt. Er ist im klinischen Umfeld – Spital,
```
Neu:

```html
          um festzustellen, ob ein normaler Riechsinn vorliegt. Er ist im klinischen Umfeld – Spital,
```

**3. Ersetzen**

Alt:

```html
            Riechstörung und präoperative Dokumentation – bei Bedarf auch postoperativ.
```
Neu:

```html
            Riechstörung mit gleichzeitiger präoperativer Dokumentation – bei Bedarf auch postoperativ.
```

**4. Ersetzen**

Alt:

```html
            folgen weitere Abklärungen, etwa die Messung der Riechschwelle mit n-Butanol.
```
Neu:

```html
            sind weitere Abklärungen empfohlen, etwa die Messung der Riechschwelle mit n-Butanol.
```

**5. Ersetzen**

Alt:

```html
      <p class="sd-note" style="max-width:860px">
```
Neu:

```html
      <p class="sd-note">
```

**6. Ersetzen**

Alt:

```html
          <figcaption>Jede Diskette trägt ihre Nummer und die Angaben zum Hersteller.</figcaption>
```
Neu:

```html
          <figcaption>Jede Diskette trägt ihre Nummer und weitere Informationen.</figcaption>
```

**7. Ersetzen**

Alt:

```html
          <figcaption>Die Identifikation erfolgt über drei Bildantworten pro Duft – am Bildschirm oder auf dem Auswertungsbogen.</figcaption>
```
Neu:

```html
          <figcaption>Die Identifikation erfolgt über drei Bildantworten pro Duft – am Bildschirm oder auf dem Formular.</figcaption>
```


## SMELL Test (`smelltest`) – 5 Änderungen

**1. CSS ergänzen** – im ersten `<style>`-Block direkt nach der Zeile
`@media print { .sdx .sd-top { display: none; } }` einfügen:

```css

/* ================================================================
   21. Hinweis unter den drei Schritten
   ================================================================ */
.sdx .sd-wdh {
  display: table; margin: 30px auto 0; padding: 12px 26px; border-radius: 999px;
  background: var(--white); box-shadow: inset 0 0 0 1.5px var(--blue-soft);
  font-size: 16px; font-weight: 700; color: var(--navy); text-align: center;
}
```

**2. Ersetzen**

Alt:

```html
          ankreuzen. Am Ende steht der Score von 0 bis 8, direkt als Ergebnisblatt
          zum Ausdrucken oder Archivieren.
```
Neu:

```html
          ankreuzen. Am Ende steht der Score von 0 bis 8 als Ergebnis zum Ausdrucken
          oder Archivieren bereit.
```

**3. Ersetzen**

Alt:

```html
        <h2 class="sd-h2">In drei Schritten zum dokumentierten Score</h2>
```
Neu:

```html
        <h2 class="sd-h2">In drei Schritten zum dokumentierten Ergebnis</h2>
```

**4. Ersetzen**

Alt:

```html
          <p>Mit einem oder beiden Nasenlöchern an der geöffneten Diskette riechen.</p>
```
Neu:

```html
          <p>Mit dem gewählten Nasenloch an der geöffneten Diskette riechen.</p>
```

**5. Ersetzen**

Alt:

```html
          <p>Aus drei Bildantworten die passende wählen. Das Ergebnis liegt sofort vor.</p>
        </article>
      </div>
```
Neu:

```html
          <p>Aus drei Bildantworten die passende wählen.</p>
        </article>
      </div>
      <p class="sd-wdh">Mit allen 8 Discettes wiederholen</p>
```


## Über uns (`ueber-uns`) – 3 Änderungen

**1. Ersetzen**

Alt:

```html
          Innovative Riechdisketten für Ärztinnen und Ärzte: für die genaue und
```
Neu:

```html
          Innovative Riechdisketten für Ärztinnen und Ärzte: für die
```

**2. Ersetzen**

Alt:

```html
            Geruchssinn wirkt sich nicht nur auf die Lebensqualität aus: Er trägt zur
            Sicherheit bei, weil er Gefahren in der Umgebung und am Arbeitsplatz
```
Neu:

```html
            Geruchssinn wirkt sich nicht nur auf die Lebensqualität aus. Er kann auch zur
            Sicherheit beitragen, weil er Gefahren in der Umgebung und am Arbeitsplatz
```

**3. Ersetzen**

Alt:

```html
            Das komplette Set mit acht Riechstoff-Disketten, Auswertungsbögen und
            Gebrauchsanweisung. Erhältlich über unsere Vertriebspartner.
```
Neu:

```html
            Das komplette <span class="sd-nw">SMELL Test-Set</span> mit acht verschiedenen Disketten in der
            TestBox, aktuellen Formularen und Gebrauchsanweisungen. Erhältlich über unsere Vertriebspartner.
```
