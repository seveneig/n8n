# Aktualisierung vom 21.10.2026 – Auftrag für Cowork

Die Website der SMELL Discettes GmbH ist bereits mit Elementor aufgebaut und auf
dem Stand der letzten Runde. Ein Backup ist gemacht. Du spielst nur die
Neuerungen dieses Pakets ein. **Nichts neu anlegen, was es schon gibt.**
Kopf- und Fusszeile, Menü und die vier Gebrauchsanweisungen bleiben unverändert.

`AUFTRAG.md` dient als Nachschlagewerk (Abschnitte „Sonderfall Online-Test" und
„Plugin «SMELL Online-Test» installieren"). Arbeite in dieser Reihenfolge:

1. **Plugin installieren.** `plugin/smell-online-test.zip` unter *Plugins →
   Installieren → Plugin hochladen* installieren und aktivieren (ist es schon
   vorhanden: vorhandene Version ersetzen). Danach muss Version **1.1.0** aktiv
   sein. Prüfen:
   `curl -X POST https://<domain>/wp-json/smell/v1/anmelden -H 'Content-Type: application/json' -d '{"pruefer":"Test","klinik":"Test","sn":"SMELL-2026-HANS","speichern":false}'`
   muss `"ok":true` sowie `"formular"` und `"pdflib"` liefern; beide Adressen
   müssen im Browser abrufbar sein. Seriennummern nur eintragen, wenn ich sie
   mitgebe – nichts erfinden.
2. **Testformular hochladen.** `downloads/SMELL_Olfaction_Test_Formular_D_ausfuellbar.pdf`
   in die Mediathek laden.
3. **Online-Test vorbereiten** (`bloecke/test.html`):
   - `downloads/SMELL_Olfaction_Test_Formular_D_ausfuellbar.pdf` durch die neue
     Mediathek-Adresse ersetzen,
   - die vier Pfade `downloads/Smell-Test_…pdf` durch die Mediathek-Adressen der
     bereits hochgeladenen Gebrauchsanweisungen ersetzen,
   - `VIDEO-URL-DER-STARTSEITE` durch die Adresse des Startseiten-Videos ersetzen.
4. **Interne Links ersetzen** in allen Blöcken – nur mit dem regulären Ausdruck
   aus `AUFTRAG.md` (`href="test.html` darf nicht in `href="smelltest.html` greifen).
5. **Zehn Seiten aktualisieren** (alle Dateien in `bloecke/`): Seite über den Slug
   finden (`seiten.json`), im vorhandenen HTML-Widget nur den Inhalt austauschen,
   Container und IDs lassen. Mit `wp_slash( wp_json_encode( … ) )` speichern.
6. **Cache und Optimierung:** Auf `/test/` Inline-JavaScript und den Ordner
   `/wp-content/plugins/smell-online-test/assets/` von Cache- und
   Optimierungs-Plugins ausnehmen; die Route `/wp-json/smell/v1/` darf kein
   Sicherheits-Plugin sperren. Danach `wp elementor flush-css`.
7. **Prüfen:**
   - Startseite, Produkt, SMELL Test, Über uns zeigen die neuen Texte; unter den
     drei Schritten steht «Mit allen 8 Discettes wiederholen».
   - `/test/`: Login mit `SMELL-2026-HANS` → Patient erfassen → 8 Disketten →
     Zusammenfassung → abschliessen. Dann „Test mit anderer Nasenöffnung desselben
     Patienten fortfahren" und einen zweiten Durchgang machen.
   - „Testformular herunterladen (PDF)": Das PDF ist ausgefüllt (Name, Vorname,
     Geburtsdatum, Kreuze beider Durchgänge, Testauswertung mit Punkten,
     Prüferin/Prüfer, Datum).
   - Im WordPress-Menü **SMELL Online-Test** ist der Zähler der SN gestiegen.
   - Browser-Konsole ohne Fehler.

Besonders wichtig:
- **Texte nicht umschreiben, kürzen oder ergänzen** – sie sind über ein Claim
  Sheet abgesichert. Das gilt auch für das PDF.
- `<script>` in `bloecke/test.html` unverändert übernehmen.

Melde zurück: Plugin-Version und Ergebnis der curl-Prüfung, die Mediathek-Adresse
des Testformulars, die aktualisierten Seiten mit IDs, das Ergebnis der Prüfungen
aus Schritt 7 und alles, was nicht wie beschrieben funktioniert hat.
