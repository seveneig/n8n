# Aktualisierung vom 21.10.2026 – Auftrag

Die Website der SMELL Discettes GmbH läuft bereits mit Elementor. Ein Backup ist
gemacht – **kein weiteres Backup nötig**. Seit der letzten Paket-Runde wurden in
Cowork eigene Änderungen gemacht. Diese **bleiben erhalten**. Du spielst nur die
Neuerungen dieses Pakets ein und überschreibst keine ganzen Seiten – mit einer
Ausnahme: dem Online-Test (Schritt 4), der komplett neu gebaut wurde.

Nicht anfassen: Kopf- und Fusszeile, Menü, FAQ, Kontakt, Vertriebspartner,
Impressum, Datenschutz, die vier Gebrauchsanweisungen in der Mediathek.

## Inhalt des Pakets

| Datei | Zweck |
|---|---|
| `plugin/smell-online-test.zip` | WordPress-Plugin «SMELL Online-Test», Version 1.1.0 |
| `downloads/SMELL_Olfaction_Test_Formular_D_ausfuellbar.pdf` | leeres, ausfüllbares Testformular |
| `AENDERUNGEN.md` | Textänderungen für Startseite, Produkt, SMELL Test, Über uns |
| `online-test/test-neu.html` | neuer Inhalt der Seite Online-Test (`/test/`) |
| `online-test/test-stand-24-09.html` | Stand der letzten Runde – nur zum Vergleich |

## Schritte

1. **Plugin installieren.** `plugin/smell-online-test.zip` unter *Plugins →
   Installieren → Plugin hochladen* installieren und aktivieren. Ist es schon
   vorhanden: die vorhandene Version ersetzen. Danach muss **Version 1.1.0**
   aktiv sein. Beim ersten Aktivieren legt es die Tabellen `wp_smell_sets` und
   `wp_smell_anmeldungen` und die Vorführ-Seriennummer `SMELL-2026-HANS` an.
   Prüfen:
   ```
   curl -X POST https://<domain>/wp-json/smell/v1/anmelden -H 'Content-Type: application/json' -d '{"pruefer":"Test","klinik":"Test","sn":"SMELL-2026-HANS","speichern":false}'
   ```
   Die Antwort muss `"ok":true` sowie `"formular"` und `"pdflib"` enthalten; beide
   Adressen müssen im Browser abrufbar sein. Seriennummern nur eintragen, wenn
   ich sie mitgebe – **nichts erfinden**.

2. **Testformular hochladen.** Das PDF aus `downloads/` in die Mediathek laden.

3. **Textänderungen** gemäss `AENDERUNGEN.md` auf Startseite, Produkt, SMELL Test
   und Über uns einarbeiten: im vorhandenen HTML-Widget nur die genannten Stellen
   ersetzen, alles andere unverändert lassen. Speichern mit
   `wp_slash( wp_json_encode( … ) )`.

4. **Online-Test ersetzen** (Seite `/test/`):
   1. Die aktuelle Live-Fassung des HTML-Widgets mit
      `online-test/test-stand-24-09.html` vergleichen. Erwartete Unterschiede sind
      nur: echte Link-Adressen statt `….html`, Mediathek-Adressen statt
      `downloads/…pdf`, die Video-Adresse statt `VIDEO-URL-DER-STARTSEITE`.
      **Alle weiteren Unterschiede sind frühere Cowork-Änderungen – auflisten.**
   2. In `online-test/test-neu.html` ersetzen:
      - die vier Pfade `downloads/Smell-Test_…pdf` durch dieselben
        Mediathek-Adressen wie in der Live-Fassung,
      - `downloads/SMELL_Olfaction_Test_Formular_D_ausfuellbar.pdf` durch die
        Adresse aus Schritt 2,
      - `VIDEO-URL-DER-STARTSEITE` durch dieselbe Video-Adresse wie in der
        Live-Fassung.
      Der einzige interne Link (`'/kontakt/?anliegen=bestellung#formular'`) ist
      schon eingesetzt; nur anpassen, falls die Kontaktseite eine andere Adresse hat.
   3. Die früheren Cowork-Änderungen aus 4.1 in `test-neu.html` übertragen, wenn
      die betroffene Stelle dort noch vorkommt und die Änderung den neuen Ablauf
      nicht verändert. Sonst nicht übertragen, sondern melden.
   4. Den Inhalt des vorhandenen HTML-Widgets durch das Ergebnis ersetzen
      (Container und IDs lassen). `<script>` unverändert übernehmen.

5. **Cache und Sicherheit.** Auf `/test/` Inline-JavaScript und den Ordner
   `/wp-content/plugins/smell-online-test/assets/` von Cache- und
   Optimierungs-Plugins ausnehmen. Die Route `/wp-json/smell/v1/` darf kein
   Sicherheits-Plugin sperren. Danach `wp elementor flush-css`.

6. **Prüfen.**
   - Startseite und SMELL Test: unter den drei Schritten steht
     «Mit allen 8 Discettes wiederholen» (als Pille, mittig). Die übrigen Texte
     aus `AENDERUNGEN.md` sind sichtbar.
   - `/test/`: Login mit `SMELL-2026-HANS` → Patient erfassen → acht Disketten →
     Zusammenfassung → «Test abschliessen». Dann «Test mit anderer Nasenöffnung
     desselben Patienten fortfahren» und einen zweiten Durchgang machen.
   - «Testformular herunterladen (PDF)» lädt ein PDF, in dem Name, Vorname,
     Geburtsdatum, die Kreuze beider Durchgänge, die Testauswertung (Kästchen und
     Punkte), Prüferin/Prüfer und Datum ausgefüllt sind.
   - Im WordPress-Menü **SMELL Online-Test** ist der Zähler der SN gestiegen.
   - Die Browser-Konsole bleibt ohne Fehler.

## Wichtig

- **Texte nicht umschreiben, kürzen oder ergänzen** – sie sind über ein Claim
  Sheet abgesichert. Das gilt auch für das PDF.
- Nichts löschen und keine Seite ganz ersetzen ausser dem Online-Test.
- Bei Zweifeln nachfragen statt anpassen.

## Rückmeldung

- Plugin-Version und Ergebnis der curl-Prüfung
- Mediathek-Adresse des Testformulars
- je Seite: welche Änderungen aus `AENDERUNGEN.md` eingearbeitet wurden und
  welche nicht (mit Grund)
- die gefundenen früheren Cowork-Änderungen am Online-Test und ob sie übertragen wurden
- Ergebnis der Prüfungen aus Schritt 6
- alles, was nicht wie beschrieben funktioniert hat
